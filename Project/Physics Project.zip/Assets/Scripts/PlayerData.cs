﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerData
{

    public float PDhighscore { get; set; }
    public float PDmusicVolume { get; set; }
    public float PDsfxVolume { get; set; }
    public int PDmusicToggle { get; set; }
    public int PDsfxToggle { get; set; }
}
